__author__ = "4424114: Marvin Glaser"

# EPR1
# Exerciise 1, 1.2 (a)
# Temperatur

celsius = input("Geben Sie eine Temperatur in Grad Celsius ein: ")
celvin = 273.15 + float(celsius)                            #conversion from celsius to celvin
print(celvin)
