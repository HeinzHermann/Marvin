#!/usr/bin/python3
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Authors: 
#    Tim Schön (timschoen95@googlemail.com):               GUI und Refactoring
#    Philipp Tertel (philipptertel@stud.uni-frankfurt.de): Refactoring
#    Mario Holldack (holldack@thi.cs.uni-frankfurt.de):    aussagenlogische Modellierung mit SymPy

from sympy import *

def Solve(k,Baummenge):
    Gk = set([ (i,j) for j in range(k)  for i in range(k) ])
    Baeume = set(Baummenge)

    B = [ [ '' for j in range(k) ] for i in range(k) ]
    Z = [ [ '' for j in range(k) ] for i in range(k) ]

    # horizontale oder vertikale Nachbarn von (i,j)
    def HV(i,j):
        return set([(i-1,j), (i+1,j), (i,j-1), (i,j+1)]).intersection(Gk)

    # horizontale, vertikale oder diagonale Nachbarn von (i,j)
    def HVD(i,j):
        D = set( [(i+1, j+1), (i-1, j+1), (i+1, j-1), (i-1, j-1)] )
        return set((HV(i,j).union(D)).intersection(Gk))
        
    # initialisiere aussagenlogische Variablen
    for i in range(k):
        for j in range(k):
            B[i][j] = symbols('B'+str((i,j)))
            Z[i][j] = symbols('Z'+str((i,j)))

    # Positionen der Bäume gemäß der Menge Baeume
    phiBaum = And(*[B[i][j] if (i,j) in Baeume else Not(B[i][j]) for (i,j) in Gk])      

    # Ein Zelt kann nur dort platziert werden, wo kein Baum steht.
    phi1 = And(*[(Not(Z[i][j]) | Not(B[i][j])) for (i,j) in Gk])

    # Ein Zelt muss horizontal oder vertikal mit einem Baum benachbart sein.
    phi2 = And(*[Or(Not(Z[i][j]),*[B[l][m] for (l,m) in HV(i,j)]) for (i,j) in Gk])

    # Zelte dürfen nicht horizontal, nicht vertikal und auch nicht diagonal benachbart sein.
    phi3 = And(*[And(*[Or( Not(Z[i][j]), Not(Z[l][m]) ) for (l,m) in HVD(i,j)]) for (i,j) in Gk])

    # In jeder Spalte muss mindestens ein Zelt stehen.
    phi4 = true
    for j in range(k):
        spaltej = false
        for i in range(k):
            spaltej = Or(spaltej, Z[i][j])
        phi4 = And(phi4, spaltej)
    
    # In jeder Zeile darf höchstens ein Zelt stehen.
    phi5 = And(*[And(*[Or(Not(Z[i][l]), Not(Z[i][m]))  for l in range(k) for m in range(l+1,k)]) for i in range(k)])

    # Alle Regeln müssen eingehalten werden
    phi = And(phiBaum, phi1, phi2, phi3, phi4, phi5)

    # Finde alle erfüllenden Belegungen
    result = satisfiable(phi, all_models=True)
    lösungen = []
    for b in result:        
        if (b == False):
            return []
        lösung = []
        for var in b:           
            if str(var)[0:2] == "(Z" and b[var]:
                lösung.append(tuple(int(i) for i in (str(var)[3:7]).split(',')))
        lösungen.append(lösung)

    return lösungen                

if __name__ == '__main__':    
    k = 10
    Baeume = [ (0,0), (1,6), (2,4), (3,8), (4,5), (5,9), (6,1), (7,7), (8,3), (9,2)]
    
    for b in Solve(k,Baeume):
        print("Zelte auf ", end="")
        for var in b:            
            print(str(var), end=", ")
        print()
