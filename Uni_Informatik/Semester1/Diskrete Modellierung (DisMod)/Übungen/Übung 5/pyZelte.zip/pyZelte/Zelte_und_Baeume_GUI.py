#!/usr/bin/python3
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Authors: 
#    Tim Schön (timschoen95@googlemail.com):               GUI und Refactoring
#    Philipp Tertel (philipptertel@stud.uni-frankfurt.de): Refactoring
#    Mario Holldack (holldack@thi.cs.uni-frankfurt.de):    aussagenlogische Modellierung mit SymPy


import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import random
import Zelte_und_Baeume

class BaumZeltGui(QWidget):
  
    def __init__(self):
        super().__init__()
        self.k = 0
        self.bäume = []
        self.lösungen = []
        self.momentane_lösung = 0

        self.baum_pixmap = QPixmap("resources/baum.png")
        self.zelt_pixmap = QPixmap("resources/zelt.png")

        self.resize(500, 100)

        self.startX = self.rect().width()-250-(self.k/2)*15
        self.startY = self.rect().height()-250-(self.k/2)*15
        
        layout = QVBoxLayout(self)
        generate_layout = QHBoxLayout(self)

        generate_box = QGroupBox("Feld erstellen")
        self.generate_button = QPushButton('Generieren', generate_box)
        self.k_label = QLabel("k = ", generate_box)
        self.k_input = QSpinBox(generate_box)
        self.generate_button.clicked.connect(self.handleGenerateButton)

        generate_layout.addWidget(self.k_label)
        generate_layout.addWidget(self.k_input)
        generate_layout.addWidget(self.generate_button)
        generate_box.setLayout(generate_layout)

        random_trees_layout = QHBoxLayout(self)
        random_trees_box = QGroupBox("Zufällige Bäume")
        self.generate_tree_button = QPushButton('Generieren', random_trees_box)
        self.count_label = QLabel("Anzahl = ", random_trees_box)
        self.count_input = QSpinBox(random_trees_box)
        self.generate_tree_button.clicked.connect(self.handleGenerateTreeButton)
        random_trees_layout.addWidget(self.count_label)
        random_trees_layout.addWidget(self.count_input)
        random_trees_layout.addWidget(self.generate_tree_button)
        random_trees_box.setLayout(random_trees_layout)

        self.solve_button = QPushButton("Lösen",self)
        self.solve_button.clicked.connect(self.solve)

        self.help_label = QLabel("Hinzufügen und Löschen von Bäumen durch Klicken auf ein Feld.", self)
        self.solution_count_label = QLabel("",self)
        
        layout.addWidget(generate_box)
        layout.addWidget(random_trees_box)
        layout.addWidget(self.help_label)
        layout.addWidget(self.solve_button)
        layout.addWidget(self.solution_count_label)
        layout.insertSpacing(5,500)

    def handleGenerateButton(self):
        self.k = self.k_input.value()
        print("set k=" + str(self.k))
        self.bäume = []
        self.lösungen = []
        self.repaint()
        self.solution_count_label.setText("")

    def handleGenerateTreeButton(self):        
        self.bäume = []
        count = min(self.count_input.value(), self.k*self.k)
        for x in range(count):
            while(True):
                bx = random.randint(0,self.k-1)
                by = random.randint(0,self.k-1)

                if((bx,by) not in self.bäume):
                    self.bäume.append((bx,by))
                    break

        print("Generierte Bäume:" + str(self.bäume))
        self.lösungen = []
        self.solution_count_label.setText("")
        self.repaint()

    def solve(self):
        self.solution_count_label.setText("Löse...")
        self.repaint()
        self.lösungen = Zelte_und_Baeume.Solve(self.k, self.bäume)  
        print("Gefundene Lösungen: " + str(self.lösungen))    
        if(len(self.lösungen) > 1):            
            self.solution_count_label.setText(str(len(self.lösungen)) + " Lösung(en) gefunden. Durchiterieren mit A/D.")
        else:
            self.solution_count_label.setText(str(len(self.lösungen)) + " Lösung(en) gefunden.")
        self.repaint()

    def mouseReleaseEvent(self, mouseevent):
        if((mouseevent.x() < self.rect().width()) and
            (mouseevent.y() < self.rect().height()) and 
            (mouseevent.x() > self.rect().width() -500) and
            (mouseevent.y() > self.rect().height() -500)):
            x = int((mouseevent.x() - self.startX)/15)
            y = int((mouseevent.y() - self.startY) / 15)

            if(x < self.k and x >= 0 and y < self.k and y >= 0):
                if((x,y) not in self.bäume):
                    self.bäume.append((x,y))
                    self.solution_count_label.setText("")
                    self.repaint()
                    self.lösungen = []
                    print("Baum auf " + str((x,y)) + " gesetzt.")
                else:
                    self.bäume.remove((x,y))
                    self.solution_count_label.setText("")
                    self.repaint()
                    self.lösungen = []
                    print("Baum auf " + str((x,y)) + " gelöscht.")

    def keyPressEvent(self, e):
        if(e.key() == Qt.Key_A and self.momentane_lösung > 0):
            e.accept()
            self.momentane_lösung -= 1
            self.repaint()
        if(e.key() == Qt.Key_D and self.momentane_lösung < len(self.lösungen)-1):
            e.accept()
            self.momentane_lösung += 1
            self.repaint()

    def paintEvent(self, event):

        if(self.k == 0):
            return;

        painter = QPainter(self)
        pen = QPen(Qt.black, 1)
        painter.setPen(pen)

        self.startX = self.rect().width()-250-(self.k/2)*15
        self.startY = self.rect().height()-250-(self.k/2)*15

        for x in range(0,self.k+1):            
            painter.drawLine(self.startX+x*15, self.startY, self.startX+15*x, self.startY+15*(self.k))

        for y in range(0,self.k+1):   
            painter.drawLine(self.startX, self.startY+15*y, self.startX+15*(self.k), self.startY+15*y)    


        for bx,by in self.bäume:
            painter.drawPixmap(self.startX+15*bx+1, self.startY+15*by+1, 13, 13, self.baum_pixmap)

        if(len(self.lösungen) > self.momentane_lösung):
            for bx,by in self.lösungen[self.momentane_lösung]:
                painter.drawPixmap(self.startX+15*bx+1, self.startY+15*by+1, 13, 13, self.zelt_pixmap)
    
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = BaumZeltGui()
    ex.show()
    sys.exit(app.exec_())
